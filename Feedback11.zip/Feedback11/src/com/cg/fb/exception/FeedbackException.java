package com.cg.fb.exception;

@SuppressWarnings("serial")
public class FeedbackException extends Exception{
	
	
		String message;

		public FeedbackException() {
			super();
		}

		public FeedbackException(String message) {
			super();
			this.message = message;
		}

		public String getMessage() {
			return message;
		}

		@Override
		public String toString() {
			return "FeedbackException message=" + message;
		}
		

}
