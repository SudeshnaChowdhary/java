package com.cg.fb.service;

import java.util.List;

import com.cg.fb.bean.CourseMaster;
import com.cg.fb.dao.CourseMasterDaoImpl;
import com.cg.fb.dao.ICourseMasterDao;
import com.cg.fb.exception.FeedbackException;


public class CourseServiceImpl implements ICourseService{
	
	ICourseMasterDao daoImpl = new CourseMasterDaoImpl();
	
	@Override
	public Integer addCourse(CourseMaster coursemaster)
			throws FeedbackException {
		
		Integer courseId=daoImpl.addCourse(coursemaster);
		return courseId;
	}

	@Override
	public List<CourseMaster> displayCourseDetails() throws FeedbackException {
		
		List<CourseMaster> courseList=daoImpl.displayCourseDetails();
		return courseList;
	}

	@Override
	public CourseMaster viewCourseDetails(int courseId)
			throws FeedbackException {
		
		CourseMaster courseMaster=daoImpl.viewCourseDetails(courseId);
		return courseMaster;
	}

	@Override
	public boolean updateCourseDetails(int courseId, CourseMaster coursemaster)
			throws FeedbackException {
		return daoImpl.updateCourseDetails(courseId, coursemaster);
		
		
	}

	@Override
	public String deleteCourseDetails(int courseId) throws FeedbackException {
		
		return daoImpl.deleteCourseDetails(courseId);
	}

	
	
}
