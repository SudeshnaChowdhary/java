package com.cg.fb.dao;

public class QueryMapper {

	public static final String ADD_COURSE_DETAILS="insert into courseMaster values(courseId_seq.NEXTVAL,?,?)";
	public static final String RETRIEVE_COURSEID="SELECT courseId_seq.CURRVAL FROM DUAL";
	public static final String VIEW_ALL_COURSEDETAILS="SELECT * from courseMaster";
	public static final String RETRIEVE_COURSE = "SELECT * FROM courseMaster WHERE courseId=?";
	public static final String UPDATE_COURSE ="UPDATE courseMaster set courseName=?,noOfDays=? where courseId=?";
	public static final String DELETE_COURSE = "DELETE FROM courseMaster WHERE courseId=?";;
	
	
	

}
