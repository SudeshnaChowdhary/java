package com.cg.fb.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.fb.bean.CourseMaster;
import com.cg.fb.exception.FeedbackException;

public interface ICourseMasterDao {
	
	public abstract Integer addCourse(CourseMaster coursemaster) throws FeedbackException;
	public abstract List<CourseMaster> displayCourseDetails() throws FeedbackException;
	public abstract CourseMaster viewCourseDetails(int courseId) throws FeedbackException;
	public abstract boolean updateCourseDetails(int courseId, CourseMaster coursemaster) throws FeedbackException; 
	public abstract String deleteCourseDetails(int courseId) throws FeedbackException;
	
	
}








