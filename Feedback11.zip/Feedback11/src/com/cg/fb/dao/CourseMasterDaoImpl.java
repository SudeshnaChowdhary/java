package com.cg.fb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fb.bean.CourseMaster;
import com.cg.fb.exception.FeedbackException;
import com.cg.fb.util.DBConnection;

public class CourseMasterDaoImpl implements ICourseMasterDao{

	@Override
	public Integer addCourse(CourseMaster coursemaster) throws FeedbackException 
	{
	
	try(
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=
					connection.prepareStatement(QueryMapper.ADD_COURSE_DETAILS);
			Statement statement=connection.createStatement();	
		){
			preparedStatement.setString(1, coursemaster.getCourseName());
			preparedStatement.setInt(2, coursemaster.getNoOfDays());
			
			int n=preparedStatement.executeUpdate();
			if(n>0) {
				//daoLogger.info("1 row added to purchase details table");
				
				ResultSet resultSet=
						statement.executeQuery(QueryMapper.RETRIEVE_COURSEID);
				if(resultSet.next()) {
					Integer courseId=resultSet.getInt(1);
					//updateCourseDetails(coursemaster.getCourseId(), coursemaster);
					return courseId;
					
				}
			}else {
				//daoLogger.info("Unable to add purchase details");
				
				System.out.println("Unable to add course details");
				throw new FeedbackException("Technical Error. Refer Logs");
			}
		}catch(SQLException e) {
			//daoLogger.error(e);
			throw new FeedbackException("Technical Error. Refer Logs");
		}
	return null;
		
	}

	
		

	@Override
	public List<CourseMaster> displayCourseDetails()
			throws FeedbackException {
		int courseCount = 0;
		try(Connection connection = DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			ResultSet resultSet = statement.executeQuery(QueryMapper.VIEW_ALL_COURSEDETAILS);
			List<CourseMaster> courseList = new ArrayList<>();
			while(resultSet.next()){
				
				courseCount++;
				CourseMaster courseMaster = new CourseMaster();
				populateCourseMaster(courseMaster,resultSet);
				courseList.add(courseMaster);
				
			}
			if(courseCount!=0){
				
				return courseList;
			}else{
				return null;
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		
		return null;
	}
			
		private void populateCourseMaster(CourseMaster courseMaster,
			ResultSet resultSet) throws SQLException  {
			courseMaster.setCourseId(resultSet.getInt("courseId"));
			courseMaster.setCourseName(resultSet.getString("courseName"));
			courseMaster.setNoOfDays(resultSet.getInt("noOfDays"));
			}




		

	@Override
	public CourseMaster viewCourseDetails(int courseId)
			throws FeedbackException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						  connection.prepareStatement(QueryMapper.RETRIEVE_COURSE);
								
		){
			preparedStatement.setInt(1, courseId);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				CourseMaster courseMaster=new CourseMaster();
				populateCourseMaster(courseMaster,resultSet);
				return courseMaster;
			}
			return null;
			
		}catch(SQLException e) {
			//daoLogger.error(e);
			throw new FeedbackException("Technical Error. Contact logs");
		}
	}

	@Override
	public boolean updateCourseDetails(int courseId, CourseMaster coursemaster)
			throws FeedbackException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
					connection.prepareStatement(QueryMapper.UPDATE_COURSE);
		){
			preparedStatement.setString(1, coursemaster.getCourseName());
			preparedStatement.setInt(2, coursemaster.getNoOfDays());
			preparedStatement.setInt(3, courseId);
			
			int n= preparedStatement.executeUpdate();
			if(n==1){
				return true;
			}
			else {
				return false;
			}
		}catch(SQLException e) {
			//daoLogger.error(e);
			throw new FeedbackException("Technical Error. Refer to Logs");
		}
	}

	@Override
	public String deleteCourseDetails(int courseId) throws FeedbackException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
					connection.prepareStatement(QueryMapper.DELETE_COURSE);
		){
			preparedStatement.setInt(1, courseId);
			int n= preparedStatement.executeUpdate();
			if(n>0) {
				//daoLogger.info("1 row deleted to purchasedetails tables");
				return "SUCCESS";
			}else {
				//daoLogger.info("delete failed,Invalid mobile Id");
				return "FAIL";
			}
		}catch(SQLException e) {
			//daoLogger.error(e);
			throw new FeedbackException("Technical Error. Refer to Logs");
		}
		
	
	}

	
	
}
