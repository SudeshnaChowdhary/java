package com.cg.fb.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.fb.bean.CourseMaster;
import com.cg.fb.exception.FeedbackException;
import com.cg.fb.service.CourseServiceImpl;
import com.cg.fb.service.ICourseService;


public class AdminConsole {
	static CourseMaster courseMaster=new CourseMaster();
	public static ICourseService courseServiceImpl = new CourseServiceImpl();
	static Scanner sc=new Scanner(System.in);
	 
	public static void main(String[] args) throws FeedbackException
	{
		
		int option;
		System.out.println("select your choice:\n"
				+"[1].Add course details\n"
				
				+"[2].view course details with particular courseId\n"
				+"[3].Display course details\n"
				+"[4].update course details\n"
				+"[5].delete course details\n"
				+"[6].exit");
		option=sc.nextInt();
		switch(option)
		{
		case 1:
		System.out.println("enter name of the course");
		String courseName = sc.next();
		
		courseMaster.setCourseName(courseName);
		
		System.out.println("enter no of days");
		int days = sc.nextInt();
		courseMaster.setNoOfDays(days);
		
		Integer courseId=courseServiceImpl.addCourse(courseMaster);
		
		System.out.println("course details with id "+courseId+" got inserted successfully");
		break;
		case 2:
			System.out.println("enter courseId");
			int courseid=sc.nextInt();
			CourseMaster course =  courseServiceImpl.viewCourseDetails(courseid);
			System.out.println(course);
			break;
		case 3:
			System.out.println("Course details available are");
			
			List<CourseMaster> list=courseServiceImpl.displayCourseDetails();
			System.out.println("Course ID  Course Name No.of Days " );
			System.out.println("--------------------------------------------");
			for(CourseMaster details:list)
				System.out.println(details.getCourseId()+"  "+details.getCourseName()+
						"  "+details.getNoOfDays());
			break;
		case 4:
			System.out.println("update course details");
			System.out.println("enter your courseId");
			int cId=sc.nextInt();
			
			//courseMaster =courseServiceImpl.viewCourseDetails(cId);
			
			/*if (courseMaster != null) {
				
				System.out.println("Course details with course Id "+cId+"are:");
				System.out.println("Course Name :"
						+ courseMaster.getCourseName());

				System.out.println("Course Duration:"
						+ courseMaster.getNoOfDays());
			}
			else {

				System.out.println("Course Id "+ cId+ " does not exist!!!" );
			}*/
			
			if(courseMaster != null) {
				System.out.println("Enter Course name to update :");
			courseName = sc.next();
			courseMaster.setCourseName(courseName);
			System.out.println("Enter No. of days to update:");
			int noOfDays = sc.nextInt();
			courseMaster.setNoOfDays(noOfDays);
			boolean f=courseServiceImpl.updateCourseDetails(cId,courseMaster);
			if(f){
				System.out.println("Course details with Id "+cId+" has been updated");
			}
			else{
				System.out.println("enter the correct data");
			}
			}
			
			break;
			case 5:
				System.out.println("delete course details");
				System.out.println("Enter Course Id");
				 int cID=sc.nextInt();
				 courseMaster = courseServiceImpl.viewCourseDetails(cID);
				 if (courseMaster != null) {
						System.out.println("Course details with course Id "+cID+"are:");
						System.out.println("Course Name :"
								+ courseMaster.getCourseName());

						System.out.println("Course Duration:"
								+ courseMaster.getNoOfDays());
				 courseServiceImpl.deleteCourseDetails(cID);
				 System.out.println("deleted");
				 }
				 else{
					 System.out.println("Course Id "+ cID+ " does not exist!so unable to delete" );
				 }
				 break;
			case 6:
				System.out.println("Exit");
				System.exit(0);
			default:
				System.out.println("Enter correct choice");
	}
}}