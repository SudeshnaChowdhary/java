package com.cg.fb.bean;

public class FeedbackMaster {

	
	private int trainingCode;
	private int participantId;
	private int fbprsComm;
	private int fbclrfydbts;
	private int fbtm;
	private int fbhndout;
	private int fbhwswntwrk;
	private String comments;
	private String suggestions;
	public FeedbackMaster() {
		super();
	}
	public FeedbackMaster(int trainingCode, int participantId, int fbprsComm,
			int fbclrfydbts, int fbtm, int fbhndout, int fbhwswntwrk,
			String comments, String suggestions) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
		this.fbprsComm = fbprsComm;
		this.fbclrfydbts = fbclrfydbts;
		this.fbtm = fbtm;
		this.fbhndout = fbhndout;
		this.fbhwswntwrk = fbhwswntwrk;
		this.comments = comments;
		this.suggestions = suggestions;
	}
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public int getFbprsComm() {
		return fbprsComm;
	}
	public void setFbprsComm(int fbprsComm) {
		this.fbprsComm = fbprsComm;
	}
	public int getFbclrfydbts() {
		return fbclrfydbts;
	}
	public void setFbclrfydbts(int fbclrfydbts) {
		this.fbclrfydbts = fbclrfydbts;
	}
	public int getFbtm() {
		return fbtm;
	}
	public void setFbtm(int fbtm) {
		this.fbtm = fbtm;
	}
	public int getFbhndout() {
		return fbhndout;
	}
	public void setFbhndout(int fbhndout) {
		this.fbhndout = fbhndout;
	}
	public int getFbhwswntwrk() {
		return fbhwswntwrk;
	}
	public void setFbhwswntwrk(int fbhwswntwrk) {
		this.fbhwswntwrk = fbhwswntwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	@Override
	public String toString() {
		return "FeedbackMaster [trainingCode=" + trainingCode
				+ ", participantId=" + participantId + ", fbprsComm="
				+ fbprsComm + ", fbclrfydbts=" + fbclrfydbts + ", fbtm=" + fbtm
				+ ", fbhndout=" + fbhndout + ", fbhwswntwrk=" + fbhwswntwrk
				+ ", comments=" + comments + ", suggestions=" + suggestions
				+ "]";
	}
	
	
	
	
}
